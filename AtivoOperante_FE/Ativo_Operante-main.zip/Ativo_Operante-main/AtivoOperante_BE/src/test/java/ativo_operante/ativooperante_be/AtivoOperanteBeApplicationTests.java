package ativo_operante.ativooperante_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtivoOperanteBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
