package ativo_operante.ativooperante_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtivoOperanteBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(AtivoOperanteBeApplication.class, args);
    }

}
