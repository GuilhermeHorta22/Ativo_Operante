package ativo_operante.ativooperante_be.repositories;

import ativo_operante.ativooperante_be.entities.Orgao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrgaoRepository extends JpaRepository<Orgao, Long> {
}
